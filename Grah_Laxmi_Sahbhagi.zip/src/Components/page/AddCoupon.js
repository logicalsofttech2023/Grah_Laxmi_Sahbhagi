import React, { useState, useEffect } from "react";

const AddCoupon = () => {
  
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-12">
          <div className="panel-content">
            <h4 className="mt-3 mb-3 text-capitalize d-flex align-items-center gap-2">
              <img width={20} src="assets/businessman.png" alt="" />
              COUPON LIST
            </h4>
            <div className="col-md-12">
              Add Coupon
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddCoupon;
